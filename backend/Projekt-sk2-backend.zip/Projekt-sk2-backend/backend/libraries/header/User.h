#pragma once

#include <string>

class User
{
public:
    std::string username;
    std::string id;
};