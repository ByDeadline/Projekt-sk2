#pragma once

enum RequestType
{
    UserLogin,
    UserLogout,
    Unknown
};