#pragma once

#include <filesystem>

class Config
{
private:
    std::filesystem::path pth1;
};