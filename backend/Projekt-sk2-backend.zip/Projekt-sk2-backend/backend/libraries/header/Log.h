#pragma once

#include <string>

class Log
{
public:
    static void Write(std::string text);
};