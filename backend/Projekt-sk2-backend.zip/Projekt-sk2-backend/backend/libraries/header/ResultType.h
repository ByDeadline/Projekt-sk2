#pragma once

enum ResultType
{
    AddUser,
    RemoveUser,
    Unknown1
};